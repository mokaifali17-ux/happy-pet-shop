HAPPY PET SHOP WEBSITE
1. Open index.html in a browser to preview the site.
2. Edit the shop phone/WhatsApp number inside index.html.
3. Replace emoji placeholders with real pet/shop photos if desired.
4. To publish, upload index.html, style.css and script.js to a static hosting service.

Location currently shown:
Near Vaishnavi Mandir, Maitripuram, Gorakhpur, Uttar Pradesh 273012
